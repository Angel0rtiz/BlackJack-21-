package blackjack;

import java.util.ArrayList;
import java.util.Random;

public class MazoCartas {
	
    private Carta mazo[];
    private int cartaActual;
    private final int NUMERO_DE_CARTAS = 52;
    private Random numeroAleatorio;
    public ArrayList<Carta> mazo_de_cartas = new ArrayList<Carta>();
    
    //Genera el mazo con las cartas
    public MazoCartas(){
	String valor[] = {"as", "dos","tres","cuatro","cinco","seis","siete","ocho","nueve","diez","jack","queen","king"};
	String figura[] ={"corazones","diamantes","picas","trebol"};
	mazo = new Carta[NUMERO_DE_CARTAS];
	cartaActual = 0;
	numeroAleatorio = new Random();
		
	for(int contador = 0;contador<mazo.length;contador++){
            mazo[contador]= new Carta(valor[contador % 13],figura[contador/13]);
	}
    }
	
    //Revuelve las cartas
    void barajar(){
	cartaActual =0;
	for(int primera=0;primera<mazo.length;primera++){
            int segunda = numeroAleatorio.nextInt(NUMERO_DE_CARTAS);
            Carta temporal = mazo[primera];
            mazo[primera]= mazo[segunda];
            mazo[segunda] = temporal;
	}
        for(int i=0;i<mazo.length;i++){
            mazo_de_cartas.add(mazo[i]);
	}
    }
    
    //Da una carta y la saca del mazo
    public Carta repartir(){
	Carta temporal;
		
	if(cartaActual < mazo_de_cartas.size()){
            temporal = mazo_de_cartas.get(cartaActual++);
            mazo_de_cartas.remove(cartaActual);
            return temporal;	
	}else
            return null;
    }
	
}
