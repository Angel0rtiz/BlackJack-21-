package blackjack;

import java.net.*;
import java.io.*;
import java.util.*;

public class Servidor {
    private static ServerSocket servidor = null; //Socket del servidor
    private static Socket j1 = null; //Socket del jugador1
    private static Socket j2 = null; //Socket del jugador2
    private static Socket j3 = null; //Socket del jugador3
    private static Socket j4 = null; //Socket del jugador4
    private static int nPartida = 0; //Indica el numero de partida
    private static final int puerto = 2020; //Puerto donde escucha el servidor
    
    public static void main(String[] args){
        //Se declara el servidor
        try{
            servidor = new ServerSocket(puerto);
        }catch(IOException e){
            System.err.println(e);
        }
        
        //Ciclo infinito para escuchar
        while(true){
            if(servidor != null){
                try{
                    System.out.println("Esperando a 4 jugadores...");
                    j1 = servidor.accept(); //Se conecta el jugador1
                    System.out.println("Esperando a 3 jugadores...");
                    j2 = servidor.accept(); //Se conecta el jugador1
                    System.out.println("Esperando a 2 jugadores...");
                    j3 = servidor.accept(); //Se conecta el jugador1
                    System.out.println("Esperando a 1 jugador...");
                    j4 = servidor.accept(); //Se conecta el jugador1
                    System.out.println("Jugadores completos. Iniciando partida.");
                    if(j1!=null && j2!=null && j3!=null && j4!=null){
                        //Se crea el hilo para la partida de uno
                        nPartida++;
                        Thread hilo = new Thread(new ServidorHilo(j1, j2, j3, j4, nPartida));
                        hilo.start(); //Inicia la ejecucion del hilo
                    }
                }catch(IOException e){
                    System.err.println(e);
                }
            }
        }
    }
}

class ServidorHilo implements Runnable{
    private final Socket j1;
    private final Socket j2;
    private final Socket j3;
    private final Socket j4;
    private final int npartida;
    
    public ServidorHilo(Socket j1, Socket j2, Socket j3, Socket j4, int npartida){
        //Se asignan los sockets recividos a los socket del hilo
        this.j1 = j1;
        this.j2 = j2;
        this.j3 = j3;
        this.j4 = j4;
        this.npartida = npartida;
    }
    
     @Override
    public void run(){
        Scanner inJ1 = null; //flujo de entrada del jugador1
        Scanner inJ2 = null; //flujo de entrada del jugador2
        Scanner inJ3 = null; //flujo de entrada del jugador3
        Scanner inJ4 = null; //flujo de entrada del jugador4
        PrintWriter outJ1 = null; //flujo de salida del jugador1
        PrintWriter outJ2 = null; //flujo de salida del jugador2
        PrintWriter outJ3 = null; //flujo de salida del jugador3
        PrintWriter outJ4 = null; //flujo de salida del jugador4
        BlackJack partida = new BlackJack(); //Partida de uno
        
        try{
            //Se asignan los flujos de entrada y de salida
            inJ1 = new Scanner(new BufferedInputStream(j1.getInputStream()));
            inJ2 = new Scanner(new BufferedInputStream(j2.getInputStream()));
            inJ3 = new Scanner(new BufferedInputStream(j3.getInputStream()));
            inJ4 = new Scanner(new BufferedInputStream(j4.getInputStream()));
            outJ1 = new PrintWriter(j1.getOutputStream());
            outJ2 = new PrintWriter(j2.getOutputStream());
            outJ3 = new PrintWriter(j3.getOutputStream());
            outJ4 = new PrintWriter(j4.getOutputStream());
        }catch(IOException e){
            System.err.println(e);
        }
        
        if(inJ1!=null && inJ2!=null && inJ3!=null && inJ4!=null && outJ1!=null && outJ2!=null && outJ3!=null && outJ4!=null){
            outJ1.println("1 Bienvenido eres el jugador 1. Comienza la partida...");
            outJ1.flush();
            outJ2.println("2 Bienvenido eres el jugador 2. Comienza la partida...");
            outJ2.flush();
            outJ3.println("3 Bienvenido eres el jugador 3. Comienza la partida...");
            outJ3.flush();
            outJ4.println("4 Bienvenido eres el jugador 4. Comienza la partida...");
            outJ4.flush();
            //Comienza el juego
            partida.jugar(inJ1, inJ2, inJ3, inJ4, outJ1, outJ2, outJ3, outJ4, npartida);
            //Cierra las conexiones cuado termina el juego
            try{
                j1.close();
                j2.close();
                j3.close();
                j4.close();
            }catch(IOException e){
                System.err.println(e);
            }
        }
    }
}

class BlackJack{
    private final int idJ1 = 1;
    private final int idJ2 = 2;
    private final int idJ3 = 3;
    private final int idJ4 = 4;
    private boolean pideOpasa = false; //True para pedir mas cartas, false para pasar turno
    private boolean gano = false; //Controla si el juego termina o no
    
    public void jugar(Scanner inJ1, Scanner inJ2, Scanner inJ3, Scanner inJ4, PrintWriter outJ1, PrintWriter outJ2, PrintWriter outJ3, PrintWriter outJ4, int npartida){
        //LLeva el puntaje de cada jugador
        ArrayList<Puntaje> puntajes = new ArrayList<>();
        //Mazo de cartas
        MazoCartas mazo = new MazoCartas();
        //Manos de los jugadores
        Mano mano1 = new Mano(idJ1);
        Mano mano2 = new Mano(idJ2);
        Mano mano3 = new Mano(idJ3);
        Mano mano4 = new Mano(idJ4);
        
        mazo.barajar(); //Barajea el mazo de cartas
        
        //Inicializa los puntajes en cero
        int cont = 1;
        for(int i=0; i<4; i++){
            puntajes.add(new Puntaje(cont));
            cont++;
        }
        
        //Reparte la primera carta a cada jugador. Esta info no se manda a los otros clientes
        repartir(idJ1, outJ1, mano1, mazo, puntajes, outJ2, outJ3, outJ4, false);
        verificaPuntaje(idJ1, puntajes, outJ1, outJ2, outJ3, outJ4); //Verifica los puntajes
        repartir(idJ2, outJ2, mano2, mazo, puntajes, outJ1, outJ3, outJ4, false);
        verificaPuntaje(idJ2, puntajes, outJ2, outJ1, outJ3, outJ4);
        repartir(idJ3, outJ3, mano3, mazo, puntajes,outJ1, outJ2, outJ4, false);
        verificaPuntaje(idJ3, puntajes, outJ3, outJ1, outJ2, outJ4);
        repartir(idJ4, outJ4, mano4, mazo, puntajes, outJ1, outJ2, outJ3, false);
        verificaPuntaje(idJ4, puntajes, outJ4, outJ1, outJ2, outJ3);
        avisaPrimeraCarta(outJ1, outJ2, outJ3, outJ4);
        
        //Reparte la segunda carta aca jugador. Desde aqui se comparte la info el juego
        repartir(idJ1, outJ1, mano1, mazo, puntajes, outJ2, outJ3, outJ4, true);
        verificaPuntaje(idJ1, puntajes, outJ1, outJ2, outJ3, outJ4);
        if(gano == false){ //Verifica si no ha terminado el juego
            repartir(idJ2, outJ2, mano2, mazo, puntajes, outJ1, outJ3, outJ4, true);
            verificaPuntaje(idJ2, puntajes, outJ2, outJ1, outJ3, outJ4);
        }
        if(gano == false){
            repartir(idJ3, outJ3, mano3, mazo, puntajes,outJ1, outJ2, outJ4, true);
            verificaPuntaje(idJ3, puntajes, outJ3, outJ1, outJ2, outJ4);
        }
        if(gano == false){
            repartir(idJ4, outJ4, mano4, mazo, puntajes, outJ1, outJ2, outJ3, true);
            verificaPuntaje(idJ4, puntajes, outJ4, outJ1, outJ2, outJ3);
        }
        
        //Verifica si es que no ha terminado el juego
        if(gano == false){
            //Turno del jugador1
            System.out.println("Partida " + npartida + " - Turno del jugador " + idJ1);
            do{
                esperarTurno(outJ2, outJ3, outJ4, idJ1);
                pideJugada(outJ1);
                pideOpasa = obtieneJugada(inJ1, outJ1);
                if(pideOpasa == true){
                    //Pide otra carta
                    System.out.println("El jugador " + idJ1 + " ha pedido mas cartas");
                    repartir(idJ1, outJ1, mano1, mazo, puntajes, outJ2, outJ3, outJ4, true);
                    verificaPuntaje(idJ1, puntajes, outJ1, outJ2, outJ3, outJ4);
                }else{
                    //Pasa el turno
                    System.out.println("El jugador " + idJ1 + " ha pasado su turno");
                    outJ1.println("6 Pasaste de turno");
                    outJ1.flush();
                    outJ2.println("6 El jugador " + idJ1 +  " paso de turno");
                    outJ2.flush();
                    outJ3.println("6 El jugador " + idJ1 +  " paso de turno");
                    outJ3.flush();
                    outJ4.println("6 El jugador " + idJ1 +  " paso de turno");
                    outJ4.flush();
                }
            }while(pideOpasa);
            imprimeEstado(puntajes);
        }
        
        if(gano == false){
            //Turno del jugador2
            System.out.println("Partida " + npartida + " - Turno del jugador " + idJ2);
            do{
                esperarTurno(outJ1, outJ3, outJ4, idJ2);
                pideJugada(outJ2);
                pideOpasa = obtieneJugada(inJ2, outJ2);
                if(pideOpasa == true){
                    //Pide otra carta
                    System.out.println("El jugador " + idJ2 + " ha pedido mas cartas");
                    repartir(idJ2, outJ2, mano2, mazo, puntajes, outJ1, outJ3, outJ4, true);
                    verificaPuntaje(idJ2, puntajes, outJ2, outJ1, outJ3, outJ4);
                }else{
                    //Pasa el turno
                    System.out.println("El jugador " + idJ2 + " ha pasado su turno");
                    outJ2.println("6 Pasaste de turno");
                    outJ2.flush();
                    outJ1.println("6 El jugador " + idJ2 +  " paso de turno");
                    outJ1.flush();
                    outJ3.println("6 El jugador " + idJ2 +  " paso de turno");
                    outJ3.flush();
                    outJ4.println("6 El jugador " + idJ2 +  " paso de turno");
                    outJ4.flush();
                }
            }while(pideOpasa);
            imprimeEstado(puntajes);
        }
        
        if(gano == false){
            //Turno del jugador3
            System.out.println("Partida " + npartida + " - Turno del jugador " + idJ3);
            do{
                esperarTurno(outJ1, outJ2, outJ4, idJ3);
                pideJugada(outJ3);
                pideOpasa = obtieneJugada(inJ3, outJ3);
                if(pideOpasa == true){
                    //Pide otra carta
                    System.out.println("El jugador " + idJ3 + " ha pedido mas cartas");
                    repartir(idJ3, outJ3, mano3, mazo, puntajes,outJ1, outJ2, outJ4, true);
                    verificaPuntaje(idJ3, puntajes, outJ3, outJ1, outJ2, outJ4);
                }else{
                    //Pasa el turno
                    System.out.println("El jugador " + idJ3 + " ha pasado su turno");
                    outJ3.println("6 Pasaste de turno");
                    outJ3.flush();
                    outJ2.println("6 El jugador " + idJ3 +  " paso de turno");
                    outJ2.flush();
                    outJ1.println("6 El jugador " + idJ3 +  " paso de turno");
                    outJ1.flush();
                    outJ4.println("6 El jugador " + idJ3 +  " paso de turno");
                    outJ4.flush();
                }
            }while(pideOpasa);
            imprimeEstado(puntajes);
        }
        
        if(gano == false){
            //Turno del jugador4
            System.out.println("Partida " + npartida + " - Turno del jugador " + idJ4);
            do{
                esperarTurno(outJ1, outJ2, outJ3, idJ4);
                pideJugada(outJ4);
                pideOpasa = obtieneJugada(inJ4, outJ4);
                if(pideOpasa == true){
                    //Pide otra carta
                    System.out.println("El jugador " + idJ4 + " ha pedido mas cartas");
                    repartir(idJ4, outJ4, mano4, mazo, puntajes, outJ1, outJ2, outJ3, true);
                    verificaPuntaje(idJ4, puntajes, outJ4, outJ1, outJ2, outJ3);
                }else{
                    //Pasa el turno
                    System.out.println("El jugador " + idJ4 + " ha pasado su turno");
                    outJ4.println("6 Pasaste de turno");
                    outJ4.flush();
                    outJ2.println("6 El jugador " + idJ4 +  " paso de turno");
                    outJ2.flush();
                    outJ3.println("6 El jugador " + idJ4 +  " paso de turno");
                    outJ3.flush();
                    outJ1.println("6 El jugador " + idJ4 +  " paso de turno");
                    outJ1.flush();
                }
            }while(pideOpasa);
            imprimeEstado(puntajes);
        }
        
        if(gano == false){
            String mensaje;
            //Mensaje jugador1
            mensaje = "10 \n";
            mensaje += "El jugador 2 tiene " + puntajes.get(1).puntaje + " puntos y su primer carta es el " + mano2.getMano().get(0).toString() + "\n";
            mensaje += "El jugador 3 tiene " + puntajes.get(2).puntaje + " puntos y su primer carta es el " + mano3.getMano().get(0).toString() + "\n";
            mensaje += "El jugador 4 tiene " + puntajes.get(3).puntaje + " puntos y su primer carta es el " + mano4.getMano().get(0).toString();
            ultimaActualizacion(mensaje, outJ1);
            //Mensaje jugador2
            mensaje = "10 \n";
            mensaje += "El jugador 1 tiene " + puntajes.get(0).puntaje + " puntos y su primer carta es el " + mano1.getMano().get(0).toString() + "\n";
            mensaje += "El jugador 3 tiene " + puntajes.get(2).puntaje + " puntos y su primer carta es el " + mano3.getMano().get(0).toString() + "\n";
            mensaje += "El jugador 4 tiene " + puntajes.get(3).puntaje + " puntos y su primer carta es el " + mano4.getMano().get(0).toString();
            ultimaActualizacion(mensaje, outJ2);
            //Mensaje jugador3
            mensaje = "10 \n";
            mensaje += "El jugador 1 tiene " + puntajes.get(0).puntaje + " puntos y su primer carta es el " + mano1.getMano().get(0).toString() + "\n";
            mensaje += "El jugador 2 tiene " + puntajes.get(1).puntaje + " puntos y su primer carta es el " + mano2.getMano().get(0).toString() + "\n";
            mensaje += "El jugador 4 tiene " + puntajes.get(3).puntaje + " puntos y su primer carta es el " + mano4.getMano().get(0).toString();
            ultimaActualizacion(mensaje, outJ3);
            //Mensaje jugador4
            mensaje = "10 \n";
            mensaje += "El jugador 1 tiene " + puntajes.get(0).puntaje + " puntos y su primer carta es el " + mano1.getMano().get(0).toString() + "\n";
            mensaje += "El jugador 2 tiene " + puntajes.get(1).puntaje + " puntos y su primer carta es el " + mano2.getMano().get(0).toString() + "\n";
            mensaje += "El jugador 3 tiene " + puntajes.get(2).puntaje + " puntos y su primer carta es el " + mano3.getMano().get(0).toString();
            ultimaActualizacion(mensaje, outJ4);
            determinaGanador(puntajes, outJ1, outJ2, outJ3, outJ4, mano1, mano2, mano3, mano4);
        }
        
    }
    
    private void avisaPrimeraCarta(PrintWriter o1, PrintWriter o2, PrintWriter o3, PrintWriter o4){
        o1.println("8 Todos los jugadores han recibido su primera carta");
        o1.flush();
        o2.println("8 Todos los jugadores han recibido su primera carta");
        o2.flush();
        o3.println("8 Todos los jugadores han recibido su primera carta");
        o3.flush();
        o4.println("8 Todos los jugadores han recibido su primera carta");
        o4.flush();
    }
    
    //Manda el mensaje cuando se revela la primera carta y el puntaje total de los demas jugadores
    private void ultimaActualizacion(String mensaje, PrintWriter o){
        o.println(mensaje);
        o.flush();
    }
    
    //Encuentra el puntaje mas grande y determina los ganadores y perdedores
    private void determinaGanador(ArrayList<Puntaje> puntajes, PrintWriter out1, PrintWriter out2, PrintWriter out3, PrintWriter out4, Mano mano1, Mano mano2, Mano mano3, Mano mano4){
        int mayor = 0, posicion = 1000, ganadorId;
        boolean bandera = false;
        
        for(int i=0; i<puntajes.size() && bandera == false; i++){
            if(puntajes.get(i).getPuntaje() <= 21){
                mayor = puntajes.get(i).getPuntaje();
                posicion = i;
                bandera = true;
            }
        }
        
        if(posicion != 1000){
            for(int i=posicion; i<puntajes.size(); i++){
                if(puntajes.get(i).getPuntaje() > mayor && puntajes.get(i).getPuntaje() <= 21){
                    mayor = puntajes.get(i).getPuntaje();
                    posicion = i;
                }
            }
            ganadorId = posicion + 1;
        }else
            ganadorId = 5;
        
        String mensaje;
        
        if(ganadorId == 1){
            System.out.println("El jugador " + ganadorId + " ha ganado");
            out1.println("3 Has ganado. Tienes un puntaje de " + puntajes.get(0).puntaje + " y es el mas alto");
            out1.flush();
            terminaJuego(ganadorId, out2, out3, out4);
        }else if(ganadorId == 2){
            System.out.println("El jugador " + ganadorId + " ha ganado");
            out2.println("3 Has ganado. Tienes un puntaje de " + puntajes.get(1).puntaje + " y es el mas alto");
            out2.flush();
            terminaJuego(ganadorId, out1, out3, out4);
        }else if(ganadorId == 3){
            System.out.println("El jugador " + ganadorId + " ha ganado");
            out3.println("3 Has ganado. Tienes un puntaje de " + puntajes.get(2).puntaje + " y es el mas alto");
            out3.flush();
            terminaJuego(ganadorId, out2, out1, out4);
        }else if(ganadorId == 4){
            System.out.println("El jugador " + ganadorId + " ha ganado");
            out4.println("3 Has ganado. Tienes un puntaje de " + puntajes.get(3).puntaje + " y es el mas alto");
            out4.flush();
            terminaJuego(ganadorId, out2, out3, out1);
        }else if(ganadorId == 5){
            System.out.println("No hubo ganador");
            out1.println("3 Has perdido. Todos tienen mas de 21");
            out1.flush();
            out2.println("3 Has perdido. Todos tienen mas de 21");
            out2.flush();
            out3.println("3 Has perdido. Todos tienen mas de 21");
            out3.flush();
            out4.println("3 Has perdido. Todos tienen mas de 21");
            out4.flush();
         }
    }
    
    //Imprime resultados de los perdedores y termina el juego
    private void terminaJuego(int id, PrintWriter outp1, PrintWriter outp2, PrintWriter outp3){
        outp1.println("3 Has perdido. El ganador es el jugador " + id);
        outp1.flush();
        outp2.println("3 Has perdido. El ganador es el jugador " + id);
        outp2.flush();
        outp3.println("3 Has perdido. El ganador es el jugador " + id);
        outp3.flush();
    }
    
    //Verifica el puntaje del jugador
    private void verificaPuntaje(int id, ArrayList<Puntaje> puntajes, PrintWriter outc, PrintWriter outp1, PrintWriter outp2, PrintWriter outp3){
        int puntaje;
        
        puntaje = puntajes.get(id-1).getPuntaje();
        
        if(puntaje == 21){
            outc.println("3 Tu puntaje es 21. Felicidades has ganado");
            outc.flush();
            System.out.println("El jugador " + id + " ha ganado");
            gano = true;
            pideOpasa = false;
            terminaJuego(id, outp1, outp2, outp3);
        }else if(puntaje > 21){
            outc.println("4 Te has pasado de 21. Estas descalificado");
            outc.flush();
            pideOpasa = false; //Para el ciclo
            avisaDescalificacion(id, outp1, outp2, outp3);
            System.out.println("El jugador " + id + " esta descalificado");
        }else{
            outc.println("5 Tu puntaje es " + puntaje);
            outc.flush();
            System.out.println("El jugador " + id + " tiene " + puntaje + " puntos");
        }
    }
    
    //Avisa a los otros jugadores cuando un jugador es descalificado
    private void avisaDescalificacion(int id, PrintWriter out1, PrintWriter out2, PrintWriter out3){
        out1.println("9 El jugador " + id + " fue descalificado");
        out1.flush();
        out2.println("9 El jugador " + id + " fue descalificado");
        out2.flush();
        out3.println("9 El jugador " + id + " fue descalificado");
        out3.flush();
    }
    
    //Reparte una carta al jugador indicado
    private void repartir(int id, PrintWriter out, Mano mano, MazoCartas mazo, ArrayList<Puntaje> puntajes, PrintWriter o1, PrintWriter o2, PrintWriter o3, boolean bandera){
        Carta tmp;
        int suma;
        
        tmp = mazo.repartir(); //Saca una carta del mazo
        mano.addCarta(tmp); //Agrega la carta a la mano del jugador
        
        //Manda el mensaje con la especificacion de la carta repartida
        out.println("2 " + tmp.toString());
        out.flush();
        //Si la bandera esta en true comparte la info con los demas jugadores
        if(bandera == true){
            o1.println("7 El jugador " + id + " recibio la carta de " + tmp.toString());
            o1.flush();
            o2.println("7 El jugador " + id + " recibio la carta de " + tmp.toString());
            o2.flush();
            o3.println("7 El jugador " + id + " recibio la carta de " + tmp.toString());
            o3.flush();
        }
        //Actualiza el puntaje del jugador
        suma = puntajes.get(id-1).getPuntaje();
        suma += tmp.getValor();
        puntajes.get(id-1).setPuntaje(suma);
        System.out.println("Al jugador " + id + " se le asigno el " + tmp.toString());
    }

    //Imprime el estado del juego
    private void imprimeEstado(ArrayList<Puntaje> puntajes){
        System.out.println("\nLos puntajes son los siguientes:");
        System.out.println("Jugador1: " + puntajes.get(0).getPuntaje());
        System.out.println("Jugador2: " + puntajes.get(1).getPuntaje());
        System.out.println("Jugador3: " + puntajes.get(2).getPuntaje());
        System.out.println("Jugador4: " + puntajes.get(3).getPuntaje() + "\n");
    }
    
    //Obtiene la jugada del cliente
    private boolean obtieneJugada(Scanner j, PrintWriter out){
        String jugada;
        
        jugada = j.nextLine();
        if(jugada.equals("otra")){
            return true;
        }else{
            return false;
        }
    }
    
    //Pregunta si el jugador quiere mas cartas o pasa el turno
    private void pideJugada(PrintWriter j){
        j.println("1 Introduzca 'otra' para obtener otra carta y 'paso' para pasar turno");
        j.flush();
    }
    
    //Pone a los demas a esperar
    private void esperarTurno(PrintWriter a, PrintWriter b, PrintWriter c, int id){
        a.println("0 Es el turno del jugador " + id + ".");
        a.flush();
        b.println("0 Es el turno del jugador " + id + ".");
        b.flush();
        c.println("0 Es el turno del jugador " + id + ".");
        c.flush();
    }
}

