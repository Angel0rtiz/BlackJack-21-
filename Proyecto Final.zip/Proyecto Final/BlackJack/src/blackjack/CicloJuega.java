package blackjack;

import java.util.*;
import java.io.*;

public class CicloJuega {
    private int nJugador, tipo;
    private String mensaje, jugada;
    private boolean terminar = false;
    private Scanner teclado = new Scanner(System.in);
    
    public void jugar(Scanner entrada, PrintWriter salida){
        //Llama a la interfaz
        Interfaz interfaz = new Interfaz();
        //Se lee que numero de jugador que se ha asignado por el servidor y avanza de linea
        nJugador = entrada.nextInt();
        StringTokenizer st;
	System.out.println("Eres el jugador " + nJugador);
        //Manda la info a la interfaz
        interfaz.setInfo("Eres el jugador " + nJugador);
	entrada.nextLine();
        String valor;
        String figura;
        int distancia;
        String mensajeF;
        int nJ;
        String puntaje;
        
        while(!terminar){
            tipo = entrada.nextInt(); //Averigua que tipo de mensaje es
            System.out.println("\n" + tipo);
            mensaje = entrada.nextLine(); //Recupera el contenido del mensaje
            
            //Decide que hacer dependiendo del tipo de mensaje
            switch(tipo){
                case 0: //Mensaje de espera
                    System.out.println(mensaje);
                    System.out.println("Esperando...");
                    //Manda la info a la interfaz
                    interfaz.setInfo(mensaje + " Esperando...");
                    break;
                case 1: //Mensaje que pide jugada
                    System.out.println(mensaje);
                    //Manda info a la interfaz
                    interfaz.setInfo(mensaje);
                    
                    jugada = interfaz.getJugada();
                    salida.println(jugada);
                    salida.flush();
                    break;
                case 2: //Mensaje de que recibiste carta
                    System.out.println("Recibi " + mensaje);
                    //Agrega la info a la interfaz
                    interfaz.setInfo("Recibiste el" + mensaje);
                    st = new StringTokenizer(mensaje);
                    valor = st.nextToken();
                    st.nextToken();
                    figura = st.nextToken();
                    //Agrega carta a la interfaz
                    interfaz.agregaTuCarta(new Carta(valor, figura));
                    break;
                case 3: //Mensaje de que el juego termino
                    System.out.println(mensaje);
                    //Manda la info a la interfaz
                    interfaz.setInfo(mensaje);
                    terminar = true;
                    break;
                case 4: //Mensaje de que tienes mas de 21, estas descalificado
                    System.out.println(mensaje);
                    //Manda la info a la interfaz
                    interfaz.setInfo(mensaje);
                    break;
                case 5: //Mensaje con tu puntuacion
                    System.out.println(mensaje);
                    //Manda la info a la interfaz
                    interfaz.setInfo(mensaje);
                    st = new StringTokenizer(mensaje);
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    puntaje = st.nextToken();
                    //Actualiza tu puntaje en la interfaz
                    interfaz.setPuntaje(puntaje);
                    break;
                case 6: //Mensaje de pasar turno
                    System.out.println(mensaje);
                    //Manda la info a la interfaz
                    interfaz.setInfo(mensaje);
                    break;
                case 7: //Recibe la info de las cartas de otros jugadores
                    System.out.println(mensaje);
                    //Agrega la info a la interfaz
                    interfaz.setInfo(mensaje);
                    st = new StringTokenizer(mensaje);
                    st.nextToken();
                    st.nextToken();
                    nJ = Integer.parseInt(st.nextToken());
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    valor = st.nextToken();
                    st.nextToken();
                    figura = st.nextToken();
                    //Agrega carta a la interfaz
                    if(nJ < nJugador){
                        distancia = nJugador - nJ;
                        if(distancia == 1)
                            interfaz.agregaCartaDer(new Carta(valor, figura));
                        else if(distancia == 2)
                            interfaz.agregaCartaEnfrente(new Carta(valor, figura));
                        else if(distancia == 3)
                            interfaz.agregaCartaIzq(new Carta(valor, figura));
                    }else if(nJ > nJugador){
                        distancia = nJ - nJugador;
                        if(distancia == 1)
                            interfaz.agregaCartaIzq(new Carta(valor, figura));
                        else if(distancia == 2)
                            interfaz.agregaCartaEnfrente(new Carta(valor, figura));
                        else if(distancia == 3){
                            interfaz.agregaCartaDer(new Carta(valor, figura));
                        }
                    }
                    break;
                case 8: //Todos los jugadores han recibido su primera carta (es la volteada)
                    System.out.println(mensaje);
                    //Se manda la info a la interfaz
                    interfaz.setInfo(mensaje);
                    //Se llaman a pintar las cartas volteadas
                    interfaz.agregaCartaDer(new Carta("volteada", "volteada"));
                    interfaz.agregaCartaIzq(new Carta("volteada", "volteada"));
                    interfaz.agregaCartaEnfrente(new Carta("volteada", "volteada"));
                    break;
                case 9: //Te avisa si algun jugador fue descalificado
                    System.out.println(mensaje);
                    //Manda la info a la interfaz
                    interfaz.setInfo(mensaje);
                    break; 
                case 10: //Te manda la primera carta de los otros jugadores
                         //Te manda la puntuacion de los otros jugadores
                    interfaz.reiniciaContadores();
                    mensajeF = entrada.nextLine();
                    System.out.println(mensajeF);
                    //Manda la info a la interfaz
                    interfaz.setInfo(mensajeF);
                    st = new StringTokenizer(mensajeF);
                    st.nextToken();
                    st.nextToken();
                    nJ = Integer.parseInt(st.nextToken());
                    st.nextToken();
                    st.nextToken(); //Puntaje
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    valor = st.nextToken();
                    st.nextToken();
                    figura = st.nextToken();
                    //Agrega las cartas a la interfaz
                    if(nJ < nJugador){
                        distancia = nJugador - nJ;
                        if(distancia == 1)
                            interfaz.agregaCartaDer(new Carta(valor, figura));
                        else if(distancia == 2)
                            interfaz.agregaCartaEnfrente(new Carta(valor, figura));
                        else if(distancia == 3)
                            interfaz.agregaCartaIzq(new Carta(valor, figura));
                    }else if(nJ > nJugador){
                        distancia = nJ - nJugador;
                        if(distancia == 1)
                            interfaz.agregaCartaIzq(new Carta(valor, figura));
                        else if(distancia == 2)
                            interfaz.agregaCartaEnfrente(new Carta(valor, figura));
                        else if(distancia == 3){
                            interfaz.agregaCartaDer(new Carta(valor, figura));
                        }
                    }
                    
                    mensajeF = entrada.nextLine();
                    System.out.println(mensajeF);
                    //Manda la info a la interfaz
                    interfaz.setInfo(mensajeF);
                    st = new StringTokenizer(mensajeF);
                    st.nextToken();
                    st.nextToken();
                    nJ = Integer.parseInt(st.nextToken());
                    st.nextToken();
                    st.nextToken(); //Puntaje
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    valor = st.nextToken();
                    st.nextToken();
                    figura = st.nextToken();
                    //Agrega las cartas a la interfaz
                    if(nJ < nJugador){
                        distancia = nJugador - nJ;
                        if(distancia == 1)
                            interfaz.agregaCartaDer(new Carta(valor, figura));
                        else if(distancia == 2)
                            interfaz.agregaCartaEnfrente(new Carta(valor, figura));
                        else if(distancia == 3)
                            interfaz.agregaCartaIzq(new Carta(valor, figura));
                    }else if(nJ > nJugador){
                        distancia = nJ - nJugador;
                        if(distancia == 1)
                            interfaz.agregaCartaIzq(new Carta(valor, figura));
                        else if(distancia == 2)
                            interfaz.agregaCartaEnfrente(new Carta(valor, figura));
                        else if(distancia == 3){
                            interfaz.agregaCartaDer(new Carta(valor, figura));
                        }
                    }
                    
                    mensajeF = entrada.nextLine();
                    System.out.println(mensajeF);
                    //Manda la info a la interfaz
                    interfaz.setInfo(mensajeF);
                    st = new StringTokenizer(mensajeF);
                    st.nextToken();
                    st.nextToken();
                    nJ = Integer.parseInt(st.nextToken());
                    st.nextToken();
                    st.nextToken(); //Puntaje
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    st.nextToken();
                    valor = st.nextToken();
                    st.nextToken();
                    figura = st.nextToken();
                    //Agrega las cartas a la interfaz
                    if(nJ < nJugador){
                        distancia = nJugador - nJ;
                        if(distancia == 1)
                            interfaz.agregaCartaDer(new Carta(valor, figura));
                        else if(distancia == 2)
                            interfaz.agregaCartaEnfrente(new Carta(valor, figura));
                        else if(distancia == 3)
                            interfaz.agregaCartaIzq(new Carta(valor, figura));
                    }else if(nJ > nJugador){
                        distancia = nJ - nJugador;
                        if(distancia == 1)
                            interfaz.agregaCartaIzq(new Carta(valor, figura));
                        else if(distancia == 2)
                            interfaz.agregaCartaEnfrente(new Carta(valor, figura));
                        else if(distancia == 3){
                            interfaz.agregaCartaDer(new Carta(valor, figura));
                        }
                    }
                    break;
            }
        }
    }
}
