package blackjack;

import java.awt.*;
import static java.lang.Thread.sleep;
import javax.swing.*;
import javax.swing.text.*;

public class Interfaz extends JFrame{
    private JLabel cj1_1;
    private JLabel cj1_2;
    private JLabel cj1_3;
    private JLabel cj1_4;
    private JLabel cj1_5;
    private JLabel cj2_1;
    private JLabel cj2_2;
    private JLabel cj2_3;
    private JLabel cj2_4;
    private JLabel cj2_5;
    private JLabel cj3_1;
    private JLabel cj3_2;
    private JLabel cj3_3;
    private JLabel cj3_4;
    private JLabel cj3_5;
    private JLabel cj4_1;
    private JLabel cj4_2;
    private JLabel cj4_3;
    private JLabel cj4_4;
    private JLabel cj4_5;
    private JLabel ePuntaje;
    private JLabel eJugada;
    private JLabel eInfo;
    private JTextArea puntaje;
    private JTextArea jugada;
    private JTextPane info;
    private int cont1 = 1;
    private int cont2 = 1;
    private int cont3 = 1;
    private int cont4 = 1;
    private static StyledDocument doc;
    private static SimpleAttributeSet informacion;
    JScrollPane scroll;
    
    public Interfaz(){
        super("Black Jack");
        setLayout(null);
        
        //Incializa las etiquetas con un fondo negro
        cj1_1 = new JLabel();
        cj1_1.setBounds(150, 570, 75, 100);
        cj1_1.setIcon(new ImageIcon(getClass().getResource("/imas/negro.png")));
        add(cj1_1);
        
        cj1_2 = new JLabel();
        cj1_2.setBounds(230, 570, 75, 100);
        cj1_2.setIcon(new ImageIcon(getClass().getResource("/imas/negro.png")));
        add(cj1_2);
        
        cj1_3 = new JLabel();
        cj1_3.setBounds(310, 570, 75, 100);
        cj1_3.setIcon(new ImageIcon(getClass().getResource("/imas/negro.png")));
        add(cj1_3);
        
        cj1_4 = new JLabel();
        cj1_4.setBounds(390, 570, 75, 100);
        cj1_4.setIcon(new ImageIcon(getClass().getResource("/imas/negro.png")));
        add(cj1_4);
        
        cj1_5 = new JLabel();
        cj1_5.setBounds(470, 570, 75, 100);
        cj1_5.setIcon(new ImageIcon(getClass().getResource("/imas/negro.png")));
        add(cj1_5);
        
        cj2_1 = new JLabel();
        cj2_1.setBounds(20, 140, 100, 75);
        cj2_1.setIcon(new ImageIcon(getClass().getResource("/imas2/negro.png")));
        add(cj2_1);
            
        cj2_2 = new JLabel();
        cj2_2.setBounds(20, 220, 100, 75);
        cj2_2.setIcon(new ImageIcon(getClass().getResource("/imas2/negro.png")));
        add(cj2_2);
        
        cj2_3 = new JLabel();
        cj2_3.setBounds(20, 300, 100, 75);
        cj2_3.setIcon(new ImageIcon(getClass().getResource("/imas2/negro.png")));
        add(cj2_3);
        
        cj2_4 = new JLabel();
        cj2_4.setBounds(20, 380, 100, 75);
        cj2_4.setIcon(new ImageIcon(getClass().getResource("/imas2/negro.png")));
        add(cj2_4);
        
        cj2_5 = new JLabel();
        cj2_5.setBounds(20, 460, 100, 75);
        cj2_5.setIcon(new ImageIcon(getClass().getResource("/imas2/negro.png")));
        add(cj2_5);
        
        cj3_1 = new JLabel();
        cj3_1.setBounds(570, 140, 100, 75);
        cj3_1.setIcon(new ImageIcon(getClass().getResource("/imas2/negro.png")));
        add(cj3_1);
        
        cj3_2 = new JLabel();
        cj3_2.setBounds(570, 220, 100, 75);
        cj3_2.setIcon(new ImageIcon(getClass().getResource("/imas2/negro.png")));
        add(cj3_2);
        
        cj3_3 = new JLabel();
        cj3_3.setBounds(570, 300, 100, 75);
        cj3_3.setIcon(new ImageIcon(getClass().getResource("/imas2/negro.png")));
        add(cj3_3);
        
        cj3_4 = new JLabel();
        cj3_4.setBounds(570, 380, 100, 75);
        cj3_4.setIcon(new ImageIcon(getClass().getResource("/imas2/negro.png")));
        add(cj3_4);
        
        cj3_5 = new JLabel();
        cj3_5.setBounds(570, 460, 100, 75);
        cj3_5.setIcon(new ImageIcon(getClass().getResource("/imas2/negro.png")));
        add(cj3_5);
        
        cj4_1 = new JLabel();
        cj4_1.setBounds(150, 20, 75, 100);
        cj4_1.setIcon(new ImageIcon(getClass().getResource("/imas/negro.png")));
        add(cj4_1);
        
        cj4_2 = new JLabel();
        cj4_2.setBounds(230, 20, 75, 100);
        cj4_2.setIcon(new ImageIcon(getClass().getResource("/imas/negro.png")));
        add(cj4_2);
        
        cj4_3 = new JLabel();
        cj4_3.setBounds(310, 20, 75, 100);
        cj4_3.setIcon(new ImageIcon(getClass().getResource("/imas/negro.png")));
        add(cj4_3);
        
        cj4_4 = new JLabel();
        cj4_4.setBounds(390, 20, 75, 100);
        cj4_4.setIcon(new ImageIcon(getClass().getResource("/imas/negro.png")));
        add(cj4_4);
        
        cj4_5 = new JLabel();
        cj4_5.setBounds(470, 20, 75, 100);
        cj4_5.setIcon(new ImageIcon(getClass().getResource("/imas/negro.png")));
        add(cj4_5);
        
        //Agrega la etiqueta 
        ePuntaje = new JLabel("Puntaje");
        ePuntaje.setFont(new Font("Helvetica", 0, 16));
        ePuntaje.setBounds(20, 570, 100, 30);
        add(ePuntaje);
        
        puntaje = new JTextArea();
        puntaje.setEditable(false);
        puntaje.setBounds(20, 600, 100, 30);
        add(puntaje);
        
        eJugada = new JLabel("Jugada");
        eJugada.setFont(new Font("Helvetica", 0, 16));
        eJugada.setBounds(560, 570, 100, 30);
        add(eJugada);
        
        jugada = new JTextArea();
        jugada.setEditable(true);
        jugada.setBounds(560, 600, 100, 30);
        add(jugada);
        
        eInfo = new JLabel("Información");
        eInfo.setFont(new Font("Helvetica", 0, 16));
        eInfo.setBounds(160, 140, 100, 30);
        add(eInfo);
        
        info = new JTextPane();
        info.setEditable(false);
        info.setBounds(160, 170, 370, 380);//540 400-30  550 400-20
        doc = info.getStyledDocument();
        informacion = new SimpleAttributeSet();
        StyleConstants.setForeground(informacion, Color.BLACK);
        
        scroll = new JScrollPane(info);
        scroll.setBounds(160, 170, 370, 380);
        add(scroll);
                
        this.getContentPane().setBackground(new Color(0, 153, 76));
        setBounds(100, 0, 700, 700);
        setResizable(false);
        setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	setVisible(true);
    }
    
    //Lee la jugada de el JTextArea jugada
    public String getJugada(){
        String j;
        try{
            sleep(15000);
        }catch(Exception e){}
        
        j = jugada.getText();
        jugada.setText("");
        
        return j;
    }
    
    //Muestra en pantalla la informacion del juego
    public void setInfo(String i){
        String out = "\n\n" + i;
	try{
            doc.insertString(doc.getLength(), out, informacion);
	}catch(Exception e){}
    }
    
    //Muestra el puntaje
    public void setPuntaje(String p){
        puntaje.setText(p);
    }
    
    //Actualiza tus cartas
    public void agregaTuCarta(Carta c){
        String direccion = seleccionaImagen(c);
        ImageIcon imagen = new ImageIcon(getClass().getResource(direccion));
        imagen.getImage().flush();
        
        if(cont1 == 1){
            cj1_1.setIcon(imagen);
            cont1++;
        }else if(cont1 == 2){
            cj1_2.setIcon(imagen);
            cont1++;
        }else if(cont1 == 3){
            cj1_3.setIcon(imagen);
            cont1++;
        }else if(cont1 == 4){
            cj1_4.setIcon(imagen);
            cont1++;
        }else if(cont1 == 5){
            cj1_5.setIcon(imagen);
            cont1++;
        }
    }
    
    //Actualiza las cartas del jugador de la izquierda
    public void agregaCartaIzq(Carta c){
        String direccion = seleccionaImagenRotada(c);
        ImageIcon imagen = new ImageIcon(getClass().getResource(direccion));
        imagen.getImage().flush();
        
        if(cont2 == 1){
            cj2_1.setIcon(imagen);
            cont2++;
        }else if(cont2 == 2){
            cj2_2.setIcon(imagen);
            cont2++;
        }else if(cont2 == 3){
            cj2_3.setIcon(imagen);
            cont2++;
        }else if(cont2 == 4){
            cj2_4.setIcon(imagen);
            cont2++;
        }else if(cont2 == 5){
            cj2_5.setIcon(imagen);
            cont2++;
        }
    }
    
    //Actualiza las cartas del jugador de la derecha
    public void agregaCartaDer(Carta c){
        String direccion = seleccionaImagenRotada(c);
        ImageIcon imagen = new ImageIcon(getClass().getResource(direccion));
        imagen.getImage().flush();
        
        if(cont3 == 1){
            cj3_1.setIcon(imagen);
            cont3++;
        }else if(cont3 == 2){
            cj3_2.setIcon(imagen);
            cont3++;
        }else if(cont3 == 3){
            cj3_3.setIcon(imagen);
            cont3++;
        }else if(cont3 == 4){
            cj3_4.setIcon(imagen);
            cont3++;
        }else if(cont3 == 5){
            cj3_5.setIcon(imagen);
            cont3++;
        }
    }   
    
    //Actualiza las cartas del jugador de enfrente
    public void agregaCartaEnfrente(Carta c){
        String direccion = seleccionaImagen(c);
        ImageIcon imagen = new ImageIcon(getClass().getResource(direccion));
        imagen.getImage().flush();
        
        if(cont4 == 1){
            cj4_1.setIcon(imagen);
            cont4++;
        }else if(cont4 == 2){
            cj4_2.setIcon(imagen);
            cont4++;
        }else if(cont4 == 3){
            cj4_3.setIcon(imagen);
            cont4++;
        }else if(cont4 == 4){
            cj4_4.setIcon(imagen);
            cont4++;
        }else if(cont4 == 5){
            cj4_5.setIcon(imagen);
            cont4++;
        }
    }
    
    //Selecciona que imagen vertical va a pintar
    private String seleccionaImagen(Carta c){
        String imagen = new String();
        
        if(c.getNombre().equals("as") && c.getFigura().equals("corazones"))
            imagen = "/imas/corazon1.png";
        else if(c.getNombre().equals("dos") && c.getFigura().equals("corazones"))
            imagen = "/imas/corazon2.png";
        else if(c.getNombre().equals("tres") && c.getFigura().equals("corazones"))
            imagen = "/imas/corazon3.png";
        else if(c.getNombre().equals("cuatro") && c.getFigura().equals("corazones"))
            imagen = "/imas/corazon4.png";
        else if(c.getNombre().equals("cinco") && c.getFigura().equals("corazones"))
            imagen = "/imas/corazon5.png";
        else if(c.getNombre().equals("seis") && c.getFigura().equals("corazones"))
            imagen = "/imas/corazon6.png";
        else if(c.getNombre().equals("siete") && c.getFigura().equals("corazones"))
            imagen = "/imas/corazon7.png";
        else if(c.getNombre().equals("ocho") && c.getFigura().equals("corazones"))
            imagen = "/imas/corazon8.png";
        else if(c.getNombre().equals("nueve") && c.getFigura().equals("corazones"))
            imagen = "/imas/corazon9.png";
        else if(c.getNombre().equals("diez") && c.getFigura().equals("corazones"))
            imagen = "/imas/corazon10.png";
        else if(c.getNombre().equals("jack") && c.getFigura().equals("corazones"))
            imagen = "/imas/corazon11.png";
        else if(c.getNombre().equals("queen") && c.getFigura().equals("corazones"))
            imagen = "/imas/corazon12.png";
        else if(c.getNombre().equals("king") && c.getFigura().equals("corazones"))
            imagen = "/imas/corazon13.png";
        else if(c.getNombre().equals("as") && c.getFigura().equals("diamantes"))
            imagen = "/imas/diamante1.png";
        else if(c.getNombre().equals("dos") && c.getFigura().equals("diamantes"))
            imagen = "/imas/diamante2.png";
        else if(c.getNombre().equals("tres") && c.getFigura().equals("diamantes"))
            imagen = "/imas/diamante3.png";
        else if(c.getNombre().equals("cuatro") && c.getFigura().equals("diamantes"))
            imagen = "/imas/diamante4.png";
        else if(c.getNombre().equals("cinco") && c.getFigura().equals("diamantes"))
            imagen = "/imas/diamante5.png";
        else if(c.getNombre().equals("seis") && c.getFigura().equals("diamantes"))
            imagen = "/imas/diamante6.png";
        else if(c.getNombre().equals("siete") && c.getFigura().equals("diamantes"))
            imagen = "/imas/diamante7.png";
        else if(c.getNombre().equals("ocho") && c.getFigura().equals("diamantes"))
            imagen = "/imas/diamante8.png";
        else if(c.getNombre().equals("nueve") && c.getFigura().equals("diamantes"))
            imagen = "/imas/diamante9.png";
        else if(c.getNombre().equals("diez") && c.getFigura().equals("diamantes"))
            imagen = "/imas/diamante10.png";
        else if(c.getNombre().equals("jack") && c.getFigura().equals("diamantes"))
            imagen = "/imas/diamante11.png";
        else if(c.getNombre().equals("queen") && c.getFigura().equals("diamantes"))
            imagen = "/imas/diamante12.png";
        else if(c.getNombre().equals("king") && c.getFigura().equals("diamantes"))
            imagen = "/imas/diamante13.png";
        else if(c.getNombre().equals("as") && c.getFigura().equals("picas"))
            imagen = "/imas/hoja1.png";
        else if(c.getNombre().equals("dos") && c.getFigura().equals("picas"))
            imagen = "/imas/hoja2.png";
        else if(c.getNombre().equals("tres") && c.getFigura().equals("picas"))
            imagen = "/imas/hoja3.png";
        else if(c.getNombre().equals("cuatro") && c.getFigura().equals("picas"))
            imagen = "/imas/hoja4.png";
        else if(c.getNombre().equals("cinco") && c.getFigura().equals("picas"))
            imagen = "/imas/hoja5.png";
        else if(c.getNombre().equals("seis") && c.getFigura().equals("picas"))
            imagen = "/imas/hoja6.png";
        else if(c.getNombre().equals("siete") && c.getFigura().equals("picas"))
            imagen = "/imas/hoja7.png";
        else if(c.getNombre().equals("ocho") && c.getFigura().equals("picas"))
            imagen = "/imas/hoja8.png";
        else if(c.getNombre().equals("nueve") && c.getFigura().equals("picas"))
            imagen = "/imas/hoja9.png";
        else if(c.getNombre().equals("diez") && c.getFigura().equals("picas"))
            imagen = "/imas/hoja10.png";
        else if(c.getNombre().equals("jack") && c.getFigura().equals("picas"))
            imagen = "/imas/hoja11.png";
        else if(c.getNombre().equals("queen") && c.getFigura().equals("picas"))
            imagen = "/imas/hoja12.png";
        else if(c.getNombre().equals("king") && c.getFigura().equals("picas"))
            imagen = "/imas/hoja13.png";
        else if(c.getNombre().equals("as") && c.getFigura().equals("trebol"))
            imagen = "/imas/trebol1.png";
        else if(c.getNombre().equals("dos") && c.getFigura().equals("trebol"))
            imagen = "/imas/trebol2.png";
        else if(c.getNombre().equals("tres") && c.getFigura().equals("trebol"))
            imagen = "/imas/trebol3.png";
        else if(c.getNombre().equals("cuatro") && c.getFigura().equals("trebol"))
            imagen = "/imas/trebol4.png";
        else if(c.getNombre().equals("cinco") && c.getFigura().equals("trebol"))
            imagen = "/imas/trebol5.png";
        else if(c.getNombre().equals("seis") && c.getFigura().equals("trebol"))
            imagen = "/imas/trebol6.png";
        else if(c.getNombre().equals("siete") && c.getFigura().equals("trebol"))
            imagen = "/imas/trebol7.png";
        else if(c.getNombre().equals("ocho") && c.getFigura().equals("trebol"))
            imagen = "/imas/trebol8.png";
        else if(c.getNombre().equals("nueve") && c.getFigura().equals("trebol"))
            imagen = "/imas/trebol9.png";
        else if(c.getNombre().equals("diez") && c.getFigura().equals("trebol"))
            imagen = "/imas/trebol10.png";
        else if(c.getNombre().equals("jack") && c.getFigura().equals("trebol"))
            imagen = "/imas/trebol11.png";
        else if(c.getNombre().equals("queen") && c.getFigura().equals("trebol"))
            imagen = "/imas/trebol12.png";
        else if(c.getNombre().equals("king") && c.getFigura().equals("trebol"))
            imagen = "/imas/trebol13.png";
        else if(c.getNombre().equals("volteada") && c.getFigura().equals("volteada"))
            imagen = "/imas/atras.png";
        
        return imagen;
    }
    
    //Selecciona que imagen horizontal va a pintar
    private String seleccionaImagenRotada(Carta c){
        String imagen = new String();
        
        if(c.getNombre().equals("as") && c.getFigura().equals("corazones"))
            imagen = "/imas2/corazon1.png";
        else if(c.getNombre().equals("dos") && c.getFigura().equals("corazones"))
            imagen = "/imas2/corazon2.png";
        else if(c.getNombre().equals("tres") && c.getFigura().equals("corazones"))
            imagen = "/imas2/corazon3.png";
        else if(c.getNombre().equals("cuatro") && c.getFigura().equals("corazones"))
            imagen = "/imas2/corazon4.png";
        else if(c.getNombre().equals("cinco") && c.getFigura().equals("corazones"))
            imagen = "/imas2/corazon5.png";
        else if(c.getNombre().equals("seis") && c.getFigura().equals("corazones"))
            imagen = "/imas2/corazon6.png";
        else if(c.getNombre().equals("siete") && c.getFigura().equals("corazones"))
            imagen = "/imas2/corazon7.png";
        else if(c.getNombre().equals("ocho") && c.getFigura().equals("corazones"))
            imagen = "/imas2/corazon8.png";
        else if(c.getNombre().equals("nueve") && c.getFigura().equals("corazones"))
            imagen = "/imas2/corazon9.png";
        else if(c.getNombre().equals("diez") && c.getFigura().equals("corazones"))
            imagen = "/imas2/corazon10.png";
        else if(c.getNombre().equals("jack") && c.getFigura().equals("corazones"))
            imagen = "/imas2/corazon11.png";
        else if(c.getNombre().equals("queen") && c.getFigura().equals("corazones"))
            imagen = "/imas2/corazon12.png";
        else if(c.getNombre().equals("king") && c.getFigura().equals("corazones"))
            imagen = "/imas2/corazon13.png";
        else if(c.getNombre().equals("as") && c.getFigura().equals("diamantes"))
            imagen = "/imas2/diamante1.png";
        else if(c.getNombre().equals("dos") && c.getFigura().equals("diamantes"))
            imagen = "/imas2/diamante2.png";
        else if(c.getNombre().equals("tres") && c.getFigura().equals("diamantes"))
            imagen = "/imas2/diamante3.png";
        else if(c.getNombre().equals("cuatro") && c.getFigura().equals("diamantes"))
            imagen = "/imas2/diamante4.png";
        else if(c.getNombre().equals("cinco") && c.getFigura().equals("diamantes"))
            imagen = "/imas2/diamante5.png";
        else if(c.getNombre().equals("seis") && c.getFigura().equals("diamantes"))
            imagen = "/imas2/diamante6.png";
        else if(c.getNombre().equals("siete") && c.getFigura().equals("diamantes"))
            imagen = "/imas2/diamante7.png";
        else if(c.getNombre().equals("ocho") && c.getFigura().equals("diamantes"))
            imagen = "/imas2/diamante8.png";
        else if(c.getNombre().equals("nueve") && c.getFigura().equals("diamantes"))
            imagen = "/imas2/diamante9.png";
        else if(c.getNombre().equals("diez") && c.getFigura().equals("diamantes"))
            imagen = "/imas2/diamante10.png";
        else if(c.getNombre().equals("jack") && c.getFigura().equals("diamantes"))
            imagen = "/imas2/diamante11.png";
        else if(c.getNombre().equals("queen") && c.getFigura().equals("diamantes"))
            imagen = "/imas2/diamante12.png";
        else if(c.getNombre().equals("king") && c.getFigura().equals("diamantes"))
            imagen = "/imas2/diamante13.png";
        else if(c.getNombre().equals("as") && c.getFigura().equals("picas"))
            imagen = "/imas2/hoja1.png";
        else if(c.getNombre().equals("dos") && c.getFigura().equals("picas"))
            imagen = "/imas2/hoja2.png";
        else if(c.getNombre().equals("tres") && c.getFigura().equals("picas"))
            imagen = "/imas2/hoja3.png";
        else if(c.getNombre().equals("cuatro") && c.getFigura().equals("picas"))
            imagen = "/imas2/hoja4.png";
        else if(c.getNombre().equals("cinco") && c.getFigura().equals("picas"))
            imagen = "/imas2/hoja5.png";
        else if(c.getNombre().equals("seis") && c.getFigura().equals("picas"))
            imagen = "/imas2/hoja6.png";
        else if(c.getNombre().equals("siete") && c.getFigura().equals("picas"))
            imagen = "/imas2/hoja7.png";
        else if(c.getNombre().equals("ocho") && c.getFigura().equals("picas"))
            imagen = "/imas2/hoja8.png";
        else if(c.getNombre().equals("nueve") && c.getFigura().equals("picas"))
            imagen = "/imas2/hoja9.png";
        else if(c.getNombre().equals("diez") && c.getFigura().equals("picas"))
            imagen = "/imas2/hoja10.png";
        else if(c.getNombre().equals("jack") && c.getFigura().equals("picas"))
            imagen = "/imas2/hoja11.png";
        else if(c.getNombre().equals("queen") && c.getFigura().equals("picas"))
            imagen = "/imas2/hoja12.png";
        else if(c.getNombre().equals("king") && c.getFigura().equals("picas"))
            imagen = "/imas2/hoja13.png";
        else if(c.getNombre().equals("as") && c.getFigura().equals("trebol"))
            imagen = "/imas2/trebol1.png";
        else if(c.getNombre().equals("dos") && c.getFigura().equals("trebol"))
            imagen = "/imas2/trebol2.png";
        else if(c.getNombre().equals("tres") && c.getFigura().equals("trebol"))
            imagen = "/imas2/trebol3.png";
        else if(c.getNombre().equals("cuatro") && c.getFigura().equals("trebol"))
            imagen = "/imas2/trebol4.png";
        else if(c.getNombre().equals("cinco") && c.getFigura().equals("trebol"))
            imagen = "/imas2/trebol5.png";
        else if(c.getNombre().equals("seis") && c.getFigura().equals("trebol"))
            imagen = "/imas2/trebol6.png";
        else if(c.getNombre().equals("siete") && c.getFigura().equals("trebol"))
            imagen = "/imas2/trebol7.png";
        else if(c.getNombre().equals("ocho") && c.getFigura().equals("trebol"))
            imagen = "/imas2/trebol8.png";
        else if(c.getNombre().equals("nueve") && c.getFigura().equals("trebol"))
            imagen = "/imas2/trebol9.png";
        else if(c.getNombre().equals("diez") && c.getFigura().equals("trebol"))
            imagen = "/imas2/trebol10.png";
        else if(c.getNombre().equals("jack") && c.getFigura().equals("trebol"))
            imagen = "/imas2/trebol11.png";
        else if(c.getNombre().equals("queen") && c.getFigura().equals("trebol"))
            imagen = "/imas2/trebol12.png";
        else if(c.getNombre().equals("king") && c.getFigura().equals("trebol"))
            imagen = "/imas2/trebol13.png";
        else if(c.getNombre().equals("volteada") && c.getFigura().equals("volteada"))
            imagen = "/imas2/atras.png";
        
        return imagen;
    }
    
    //Reinicia los contadores para voltear la primera carta
    public void reiniciaContadores(){
        cont1 = 1;
        cont2 = 1;
        cont3 = 1;
        cont4 = 1;
    }
}
