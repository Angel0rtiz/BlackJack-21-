package blackjack;

import java.util.*;

public class Mano {
    int jugador;
    ArrayList<Carta> mano = new ArrayList<>();
    
    public Mano(int j){
        jugador = j;
    }
    
    public void addCarta(Carta c){
        mano.add(c);
    }
    
    public int getJugador(){
        return jugador;
    }
    
    public ArrayList<Carta> getMano(){
        return mano;
    }
}
