package blackjack;

public class Puntaje {
    int jugador;
    int puntaje;
    
    public Puntaje(int j, int p){
        jugador = j;
        puntaje = p;
    }
    
    public Puntaje(int j){
        jugador = j;
        puntaje = 0;
    }
    
    public void setJugador(int j){
        jugador = j;
    }
    
    public void setPuntaje(int p){
        puntaje = p;
    }
    
    public int getJugador(){
        return jugador;
    }
    
    public int getPuntaje(){
        return puntaje;
    }
}
