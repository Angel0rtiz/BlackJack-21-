package blackjack;

import java.io.*;
import java.net.*;
import java.util.*;

//lo primero que se hace es abrir un socket de tipo socket 
public class Cliente {
    //Se declara el socket
    private static Socket socket = null;
    //Se declaran los flujos
    private static PrintWriter salida = null;
    private static Scanner entrada = null;

    public static void main(String[] args) {
        try{ 
            //Se conecta con el cliente con el servidor
            socket = new Socket("localhost", 2020);
            System.out.println("Se ha establecido conexion con el servidor"); //se muestra el mensaje que ya se ha conectado al servidor
            
            //Se conectan los flujos
            salida = new PrintWriter(socket.getOutputStream()); 
            entrada = new Scanner(new BufferedInputStream(socket.getInputStream())); 
	}catch(UnknownHostException e){
            e.printStackTrace();
	}catch(IOException e){
            e.printStackTrace();
        }
	
        //Se crea una clase donde esta la logica del cliente
        CicloJuega juego;
        juego = new CicloJuega();
        juego.jugar(entrada, salida);
    }
}