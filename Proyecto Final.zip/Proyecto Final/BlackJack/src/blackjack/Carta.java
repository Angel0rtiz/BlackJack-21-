package blackjack;

public class Carta {
    private final String valor;
    private final String figura;
	
	
    public Carta(String cardValor, String cardFigura){
	valor = cardValor;
	figura = cardFigura;
    }
    
    //Regresa el valor numerico de la carta
    public int getValor(){
        if(valor.equals("as"))
            return 11;
        else if(valor.equals("dos"))
            return 2;
        else if(valor.equals("tres"))
            return 3;
        else if(valor.equals("cuatro"))
            return 4;
        else if(valor.equals("cinco"))
            return 5;
        else if(valor.equals("seis"))
            return 6;
        else if(valor.equals("siete"))
            return 7;
        else if(valor.equals("ocho"))
            return 8;
        else if(valor.equals("nueve"))
            return 9;
        else if(valor.equals("diez"))
            return 10;
        else if(valor.equals("jack"))
            return 10;
        else if(valor.equals("queen"))
            return 10;
        else if(valor.equals("king"))
            return 10;
        else
            return 0;
    }
    
    public String getNombre(){
        return valor;
    }
    
    public String getFigura(){
        return figura;
    }
	
    @Override
    public String toString(){
	return valor + " de "+figura;
    }

}
